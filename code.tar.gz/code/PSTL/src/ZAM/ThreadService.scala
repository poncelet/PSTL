package ZAM

trait ThreadService {

}