package ZAM

class Thread {

}