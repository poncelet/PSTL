package ZAM

object Programme {
  
  var path = ""
    /* Init zam */
  
	def setprog(newpath : String) = {
	  path = newpath
	}
	
	def saveprog() = {
	  
	}
	
	def execute() = {
	  
	}
}