object Main {
	def main(args: Array[String]) {
	  val f = new IHM.WMainEvents(null)
	}
}