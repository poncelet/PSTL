object Main {
	def main(args: Array[String]) {
	  /**
	   * Test implantation
	   * 1) Un thread et instruction simple
	   */
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.const, 2)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.push)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.const, 4)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.push)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.constint, 50)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.setglobal, 3)
	 
	 ZAM.Simulateur.Preparer()
	 //print
	 print(ZAM.Simulateur.toString())
	 
	 ZAM.Simulateur.Initthread
	 //execution
	 ZAM.Simulateur.Avancer(0, 5)
	 
	 println(ZAM.Simulateur.printthread(0))
	 
	 ZAM.Simulateur.Revenir(2)
	 
	  //print
	 println(ZAM.Simulateur.printthread(0))
	 println(ZAM.Simulateur.printenv())
	  
	 ZAM.Simulateur.Avancer(0, 3)
	  
	   //print
	 println(ZAM.Simulateur.printthread(0))
	 println(ZAM.Simulateur.printenv())
	  
	  /**
	   * Test graphique
	   */
	  val f = new IHM.WMainEvents(null)
	}
}