object Main {
	def main(args: Array[String]) {
	  
	  val Simulateur = new ZAM.Simulator()
	  
	  /**
	   * Test implantation
	   * 4) thread et blocs (Double Array)
	   */
	 
	 Simulateur.AST.add(new ZAM.Const(156))
	 Simulateur.AST.add(new ZAM.Pushconst(123))
	 
	 Simulateur.AST.add(new ZAM.Makeblock(2, ZAM.BlockT.double_t.id))
	 Simulateur.AST.add(new ZAM.Pop(0))
	 Simulateur.AST.add(new ZAM.Setglobal(0))
	 
	 Simulateur.AST.add(new ZAM.Const(256))
	 Simulateur.AST.add(new ZAM.Pushconst(223))
	 Simulateur.AST.add(new ZAM.Makeblock(2, ZAM.BlockT.double_t.id))
	 
	 Simulateur.AST.add(new ZAM.Pop(0))
	 Simulateur.AST.add(new ZAM.Setglobal(1))
	 Simulateur.AST.add(new ZAM.Const(356))
	 Simulateur.AST.add(new ZAM.Pushconst(323))
	 Simulateur.AST.add(new ZAM.Makeblock(2, ZAM.BlockT.double_t.id))
	 
	 Simulateur.AST.add(new ZAM.Pop(0))
	 Simulateur.AST.add(new ZAM.Setglobal(2))
	 Simulateur.AST.add(new ZAM.Const(456))
	 Simulateur.AST.add(new ZAM.Pushconst(423))
	 Simulateur.AST.add(new ZAM.Makeblock(2, ZAM.BlockT.double_t.id))
	 
	 Simulateur.AST.add(new ZAM.Pop)
	 Simulateur.AST.add(new ZAM.Setglobal(3))
	 Simulateur.AST.add(new ZAM.Const(556))
	 Simulateur.AST.add(new ZAM.Pushconst(523))
	 Simulateur.AST.add(new ZAM.Makeblock(2, ZAM.BlockT.double_t.id))
	 
	 Simulateur.AST.add(new ZAM.Pop)
	 
	 Simulateur.AST.add(new ZAM.Pushgetglobal(3))
	 Simulateur.AST.add(new ZAM.Pushgetglobal(2))
	 Simulateur.AST.add(new ZAM.Pushgetglobal(1))
	 Simulateur.AST.add(new ZAM.Pushgetglobal(0))
	 
	 Simulateur.AST.add(new ZAM.Makefloatblock(5))
	 
	 Simulateur.AST.add(new ZAM.Setglobal(4))
	 
	 Simulateur.AST.add(new ZAM.Getglobal(4))
	  
	 Simulateur.AST.add(new ZAM.Getfloatfield(2))
	 
	 Simulateur.AST.add(new ZAM.Pushgetglobal(4))
	 
	 Simulateur.AST.add(new ZAM.Setfloatfield(1))
	 
	 Simulateur.Preparer()
	 //print
	 print(Simulateur.toString())
	 
	 //un thread
	 Simulateur.Env.pushthread(new ZAM.ThreadState)

	 //execution
	 Simulateur.Avancer(0, 2)
	 println("*********************\n")
	 println(Simulateur.printthread(0))
	 println(Simulateur.printenv())
	 
	  Simulateur.Avancer(0, 2)
	 println("*********************\n")
	 println(Simulateur.printthread(0))
	 println(Simulateur.printenv())
	 
	  Simulateur.Avancer(0, 2)
	 println("*********************\n")
	 println(Simulateur.printthread(0))
	 println(Simulateur.printenv())
	 
	  Simulateur.Avancer(0, 28)
	 println("*********************\n")
	 println(Simulateur.printthread(0))
	 println(Simulateur.printenv())
	  
	  /**
	   * Test graphique
	   */
	  val f = new IHM.WMainEvents(null)
	}
}