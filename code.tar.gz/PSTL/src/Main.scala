object Main {
	def main(args: Array[String]) {
	  /**
	   * Test implantation
	   * 2) Deux threads et instruction simple
	   */
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.const, 2)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.push)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.const, 4)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.push)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.constint, 50)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.setglobal, 3)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.constint, 10)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.setglobal, 2)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.constint, 55)
	 ZAM.Simulateur.CreationInstr(ZAM.instrT.setglobal, 3)
	 
	 ZAM.Simulateur.Preparer()
	 //print
	 print(ZAM.Simulateur.toString())
	 
	 //deux threads
	 ZAM.Simulateur.Initthread
	 ZAM.Simulateur.Initthread
	 
	 //execution
	 ZAM.Simulateur.Avancer(0, 8)
	 println("*********************\n")
	 println(ZAM.Simulateur.printthread(0))
	 println(ZAM.Simulateur.printenv())
	 
	  //execution
	 ZAM.Simulateur.Avancer(1, 10)
	 println("*********************\n")
	 println(ZAM.Simulateur.printthread(1))
	 println(ZAM.Simulateur.printenv())
	 
	 ZAM.Simulateur.Revenir(4)
	 
	  //print
	 println("*********************\n")
	 println(ZAM.Simulateur.printthread(0))
	 println(ZAM.Simulateur.printthread(1))
	 println(ZAM.Simulateur.printenv())
	  
	 ZAM.Simulateur.Avancer(0, 2)
	  
	   //print
	 println("*********************\n")
	 println(ZAM.Simulateur.printthread(0))
	 println(ZAM.Simulateur.printenv())
	  
	  /**
	   * Test graphique
	   */
	  val f = new IHM.WMainEvents(null)
	}
}