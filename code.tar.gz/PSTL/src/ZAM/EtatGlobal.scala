package ZAM
import java.util.ArrayList
import java.util.HashMap

/**
 * L'état global du programme, il possède les variable globales et les threads existantes
 * Des fonctions d'acces aux variables locales pour une thread sont faites
 */
object EtatGlobal {
  var glob = new HashMap[Int, Value]() // Tas
  var extra_args = 0
  val Threads = new ArrayList[EtatThread]()
  
  /**
   * Gestion des variables globales
   */
  def getglob = glob
  def addglob(i : Int, v : Value) = glob.put(i, v)
  def setglob(nenv : HashMap[Int, Value]) = glob = nenv
  
  /**
   * Gestion de l'environnement d'une thread
   */
  def getenv(t : Int, i : Int) = Threads.get(t).getenv(i)
  def setenv(t : Int, i : Int, v : Value) = Threads.get(t).setenv(i,v)
  
  /**
   * Gestion de la pile d'une thread
   */
  def getsp(t :Int) = Threads.get(t).getsp
  def addsp(t: Int, v : Value) = Threads.get(t).addsp(v)
  
  /**
   * Gestion de l'accumulateur d'une thread
   */
  def getaccu(t: Int) = Threads.get(t).getaccu
  def setaccu(t: Int, v : Value) = Threads.get(t).setaccu(v) 
  
  /**
   * Gestion du pc d'une thread
   */
  def getpc(t : Int) = Threads.get(t).getpc
  def setpc(t : Int, v : Int) = Threads.get(t).setpc(v)
  
  /**
   * Gestion de l'extra args
   */
  def getextra = extra_args
  def setextra(v : Int) = extra_args = v
  
  /**
   * Gestion des threads
   */
  def addthread(t : EtatThread) = Threads.add(t)
  def removethread(i : Int) = Threads.remove(i)
  def getthread(i : Int) = Threads.get(i)
  
  /**
   * Restaurer la thread et l'environnement global
   * dans l'état où il etait à la n° instruction de la thread t
   */
  def restaurer(t : Int, n : Int) = Threads.get(t).restaurer(n)
  
  override def toString() = { var str = "Environnement global : "
	  						if(glob.size == 0) str = str + "[]"
	  						else str=str + glob.toString
	  						str
  							}
  def printT(t : Int) = "Thread n°" + t + "::" + Threads.get(t).toString()
}