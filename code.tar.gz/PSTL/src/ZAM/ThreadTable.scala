package ZAM

class ThreadTable(table : Array[ThreadState]) {
  
  def push(t : ThreadState) = table.update(table.length, t)
  def remove(i : Int) = { // a revoir
    val tmp = new Array[ThreadState](0)
    for(j<-0 to table.length) if(j != i) tmp.update(tmp.length, table(j))
  }
  def get(i : Int) : ThreadState = table(i)
}