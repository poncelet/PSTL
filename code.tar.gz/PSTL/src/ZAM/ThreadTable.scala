package ZAM
import scala.collection.mutable.ArrayBuffer

class ThreadTable(table : ArrayBuffer[ThreadState]) {
  
  def push(t : ThreadState) = table += t
  def remove(i : Int) = { // a revoir
    val tmp = new Array[ThreadState](0)
    for(j<-0 to table.length) if(j != i) tmp.update(tmp.length, table(j))
  }
  def get(i : Int) : ThreadState = table(i)
}