package ZAM
import java.util.ArrayList


/**
 * Les valeurs gérées par la ZAM
 */
abstract class Value {

}
/**
 * Un long
 */
class Zamlong (value : Long) extends Value {
  def getval = value
  override def toString = "long : " + value
}

/**
 * Un entier
 */
class Zamentier (value : Int) extends Value {
  def getval = value
  override def toString = "entier : " + value 
}

/**
 * Un bloc
 */

class Zamblock (tag : blockT.blockT, size : Long, value : ArrayList[Value] ) extends Value {
  
  def getval = value
  def getsize = size
  def gettag = tag
  
  def at(n : Int) = value.get(n) 
  def set(n : Int, v : Value) =  value.set(n, v) 
  
  override def toString = tag match {
    case blockT.abstract_t => "abstract de " + size + " : " + value.toString 
    case blockT.string_t => "string de " + size + " : " + value.toString 
    case blockT.double_t => "double de " + size + " : " + value.toString 
    case blockT.doublearray_t => "tableau de double de " + size + " : " + value.toString 
    case blockT.foward_t => "foward de " + size + " : " + value.toString 
    case blockT.infix_t => "infix de " + size + " : " + value.toString 
    case blockT.object_t => "object de " + size + " : " + value.toString 
    case blockT.closure_t => "closure de " + size + " : " + value.toString 
    }
}