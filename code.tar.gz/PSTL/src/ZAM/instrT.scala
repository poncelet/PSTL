package ZAM

/**
 * Enumeration des types d'instruction
 * Basic stack / environnement / block operations
 */
object instrT extends Enumeration {
	type instrT = Value
	val acc, push, pushacc, pop, assign,
	pushgetglobal, getglobal, getglobalfield, setglobal, envacc, pushenvacc, pushgetglobalfield,
	getfield, getfloatfield, setfield, setfloatfield, pushatom, atom, makeblock, makefloatblock, 
	const, pushconst, pushconstint, constint
	= Value
}