package ZAM

/**
 * Simulateur, point d'entrée de la ZAM. 
 */
class Simulator {
  
  /**
   * Données graphiques
   */
	var path = ""
    var Ready = false
    
  /**
   * Données corps
   */
    val MyAST = new AST(null)
	val MyEnv = new GlobalState
	val MySManager = new StateManager
	val MyEval = new Evaluator

    /**
     * Gestion au path du programme 
     */
	def setprog(newpath : String) = {
	  path = newpath
	}
	
	def Sauvegarder() {
	  /** code (gestion graphique) */
	}
	
	def Charger(s : String){
	  /** code (gestion graphique) */
	}
	
	/**
	 * Accesseurs
	 */
	def AST = MyAST
	def Env = MyEnv
	def Manager = MySManager
	def Eval = MyEval
	
	/**
	 * Preparation de l'ast depuis le source
	 */
	def Preparer() = {
	  Ready = true
	}
	
	/**
	 * Faire avancer la thread t de n pas
	 * Le simulateur gère le liens entre le pc de la thread et l'AST
	 * (la sauvegarde lors d'une avancée est faites dans instruction)
	 */
	def Avancer(t : Int, n : Int) {
	  if(!Ready) throw new Exception("erreur")
	  MySManager.save(MyEnv, t)
	  //avancer n pas
	  for(i<-0 to n-1) {
		  AST.avancer(t)
	  }
	}
	
		/**
	 * Restaurer
	 */
	def Revenir(n : Int) {
	  if(!Ready) throw new Exception("erreur")
	  /**
	   * Prendre en compte les autres threads ? Remonter par threads ?
	   * Méthode courante : restaurer le n° state (ne prennant pas en compte le nombre d'exec de la thread)
	   */
	  //remonter le log de n pas (_2 !
	  var t = 0
	  var sum = 0
	  while(sum < n) {sum = sum + log.get(log.size-1-t)._2; t = t + 1}
	  val it = log.get(log.size-t)
	  val stateit = EtatGlobal.getthread(it._1).getchemin
	  
	  EtatGlobal.restaurer(it._1, n+1)
	  /** autre methode
	  // si n petit :> Calculer de tete à n le nombre d'execution de la thread et restaurer l'etat
	 var sum = 0
	 for(i<-0 to n) if(log.get(log.size - i)._1 == stat._1) sum = sum + 1
	 val chemin = EtatGlobal.getthread(stat._1).getchemin
	  */
	 //EtatGlobal.setaccu(chemin.get(chemin.size() - sum).getaccu)
	}
	
	override def toString = AST.toString()
	
	def printthread(t: Int) = EtatGlobal.printT(t)
	
	def printenv() = EtatGlobal.toString()
	
}