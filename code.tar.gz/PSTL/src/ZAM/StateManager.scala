package ZAM
import scala.collection.mutable.HashMap

/**
 * Gestionnaire de sauvegarde d'état
 * Il garde et gère chaque état pour chaque thread
 */
class StateManager {

	val chemin = new Array[Array[State]](0)

	/**
	 * Sauve dans le chemin correspondant, l'état de la thread
	 */
	def save(MyEnv : GlobalState, itT : Int) = {	
	  val thread = MyEnv.getthread(itT)
	  // Copy de pile
		val stk = new Array[Value](thread.getsp.size)
		for(i<-0 to thread.getsp.size-1) stk.update(i, thread.getsp(i))
		//Copy de tas
		val globtmp = new HashMap[Int, Value]()
		MyEnv.getglob.foreach(ent => globtmp.+=(ent))
		var envtmp = new Array[Value](4)
		for(i<-0 to 4) envtmp(i) = thread.getenv(i)
		val tab  = chemin(itT)
		tab.update(tab.length, new State(thread.getpc, stk, thread.getaccu, envtmp ,globtmp, thread.getextra))
		chemin.update(itT, tab)
	}
	
	/**
	 * Restaure le n° chemin (et met aussi à jour le chemin)
	 */
	def restaurer(n : Int) = { val stateit = getchemin.get(getchemin.size - (n-1))
		// Restaurer Pile
		sp.clear()
		for(i<-0 to stateit.getsp.size-1) sp.add(stateit.getsp.get(i))
		// Valeurs globales : Restauration des anciennes valeurs sans suppressions du tout 
		// (évite de faire disparaître les variables d'autres threads)
		EtatGlobal.getglob.putAll(stateit.getglob)
		//EtatGlobal.setglob(new HashMap[Int, Value](stateit.getglob))
		// Environnement
		env.clear
		if(stateit.getenv.size > 0) {
			for(i<-0 to stateit.getenv.size) setenv(i, stateit.getenv.get(i)) 
		}
	// Restaurer tas

	pc = stateit.getpc
	accu = stateit.getaccu
	EtatGlobal.setextra(stateit.getextra)
	// Restaurer le chemin
	for(i<-0 to n) chemin.remove(chemin.size()-1)
	}

}