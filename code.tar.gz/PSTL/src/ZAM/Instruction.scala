package ZAM
import java.util.ArrayList

/**
 * Implantation des instructions (interpret)
 * arg permet de factoriser les ACC(n) et autres instructions de ce type
 * Pour les instructions ayant besoin de valeur, elles sont passées en argument
 */
abstract class Instruction () {
  
  override def toString = print(this)
  
  def print(t : Instruction) : String = t match {
	  case Acc(arg) => "acc " + arg + "\n"
	  case Push() => "push\n"
	  case Pushacc(arg) => "pushacc " + arg + "\n"
	  case Pop(arg) => "pop " + arg + "\n"
	  case Assign(arg) => "assign " + arg + "\n"
	  
	  case Envacc(arg) => "envacc " + arg + "\n"
	  case Pushenvacc(arg) => "pushenvacc " + arg + "\n"
	  
	  case Push_Retaddr(pc) => "push_retaddr " + pc + "\n"
	  case Apply(arg) => "apply " + arg + "\n"
	  case Appterm(nargs, slotSize) => "appterm " + nargs + ", " + slotSize + "\n"
	  case Return(sp) => "return " + sp + "\n" 
	  case Restart() => "restart \n"
	  case Grab(required) => "grab " + required + "\n"
	  case Closure(nvars) => "closure " + nvars + "\n"
	  case Closurerec(nfuncs, nvars) => "closurerec " + nfuncs + ", " + nvars + "\n"
	  case Pushoffsetclosure(arg) => "pushoffsetclosure " + arg + "\n"
	  case Offsetclosure(arg) => "offsetclosure " + arg + "\n"
	  case Pushoffsetclosurem(arg) => "pushoffsetclosurem " + arg + "\n"
	  case Offsetclosurem(arg) => "offsetclosurem " + arg + "\n"
	    
	  case Pushgetglobal(arg) => "pushgetglobal " + arg + "\n"
	  case Getglobal(arg) => "getglobal " + arg + "\n"
	  case Getglobalfield(arg, field) => "getglobalfield " + arg + " : " + field + " \n"
	  case Setglobal(arg) => "setglobal " + arg + "\n"
	  case Pushgetglobalfield(arg, field) => "pushgetglobalfield " + arg + " : " + field + " \n"
	    
	  case Getfield(arg) => "getfield " + arg + "\n"
	  case Getfloatfield(arg) => "getfloatfield " + arg + "\n"
	  case Setfield(arg) => "setfield " + arg + "\n"
	  case Setfloatfield(arg) => "setfloatfield " + arg + "\n"
	  case Pushatom(arg) => "pushatom " + arg + "\n"
	  case Atom(arg) => "atom " + arg + "\n"
	  case Makeblock(size, typ) => "makeblock :size " + size + " :type: " + BlockT.apply(typ).toString() + "\n"
	  case Makefloatblock(size) => "makefloatblock :size " + size + "\n"
	    
	  case Const(arg) => "const " + arg + "\n"
	  case Pushconst(arg) => "pushconst " + arg + "\n"
	  case Pushconstint(arg) => "pushconstint (" + arg + ")\n"
	  case Constint(arg) => "constint (" + arg + ")\n"
	    
	  case _ => "Instruction inconnue"
	}
}

/**
 * Les instructions possibles de la ZAM
 */

case class Acc(arg : Int) extends Instruction
case class Push extends Instruction
case class Pushacc(arg : Int) extends Instruction
case class Pop(arg : Int = 0) extends Instruction
case class Assign(arg : Int) extends Instruction

case class Envacc(arg : Int) extends Instruction
case class Pushenvacc(arg : Int) extends Instruction

case class Push_Retaddr(pc : Int) extends Instruction
case class Apply(arg : Int) extends Instruction //check_stacks
case class Appterm(nargs : Int, slotSize : Int) extends Instruction
case class Return(sp : Int) extends Instruction
case class Restart extends Instruction
case class Grab(required : Int) extends Instruction
case class Closure(nvars : Int) extends Instruction
case class Closurerec(nfuncs : Int, nvars : Int) extends Instruction
case class Pushoffsetclosure(arg : Int) extends Instruction
case class Offsetclosure(arg : Int) extends Instruction
case class Pushoffsetclosurem(arg : Int) extends Instruction
case class Offsetclosurem(arg : Int) extends Instruction

case class Pushgetglobal(arg : Int) extends Instruction
case class Getglobal(arg : Int) extends Instruction
case class Getglobalfield(arg : Int, field : Int) extends Instruction
case class Setglobal(arg : Int) extends Instruction
case class Pushgetglobalfield(arg: Int, field : Int) extends Instruction

case class Getfield(arg : Int) extends Instruction
case class Getfloatfield(arg : Int) extends Instruction
case class Setfield(arg : Int) extends Instruction
case class Setfloatfield(arg : Int) extends Instruction
case class Pushatom(arg : Int) extends Instruction
case class Atom(arg : Int) extends Instruction
case class Makeblock(size : Int, typ : Int) extends Instruction
case class Makefloatblock(size : Int) extends Instruction

case class Const(arg : Int) extends Instruction
case class Pushconst(arg : Int) extends Instruction
case class Pushconstint(arg : Int) extends Instruction
case class Constint(arg : Int) extends Instruction