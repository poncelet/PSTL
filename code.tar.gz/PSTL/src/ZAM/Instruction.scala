package ZAM
import java.util.ArrayList

/**
 * Implantation des instructions (interpret)
 * arg permet de factoriser les ACC(n) et autres instructions de ce type
 * Pour les instructions ayant besoin de valeur, elles sont passées en argument
 */
abstract class Instruction () {
  override def toSting = print(this)
  def print(t : Instruction) = t match {
	  case acc(arg) => "acc" + arg + "\n"
	  case push => "push\n"
	  case pushacc(arg) => "pushacc" + arg + "\n"
	  case pop(arg) => "pop" + arg + "\n"
	  case assign(arg) => "assign" + arg + "\n"
	  
	  case envacc(arg) => "envacc" + arg + "\n"
	  case pushenvacc(arg) => "pushenvacc" + arg + "\n"
	    
	  case pushgetglobal(arg) => "pushgetglobal" + arg + "\n"
	  case getglobal(arg) => "getglobal" + arg + "\n"
	  case getglobalfield(arg, field) => "getglobalfield" + arg + " : " + field + " \n"
	  case setglobal(arg) => "setglobal" + arg + "\n"
	  case pushgetglobalfield(arg, field) => "pushgetglobalfield" + arg + " : " + field + " \n"
	    
	  case getfield(arg) => "getfield" + arg + "\n"
	  case getfloatfield(arg) => "getfloatfield" + arg + "\n"
	  case setfield(arg) => "setfield" + arg + "\n"
	  case setfloatfield(arg) => "setfloatfield" + arg + "\n"
	  case pushatom(arg) => "pushatom" + arg + "\n"
	  case atom(arg) => "atom" + arg + "\n"
	  case makeblock(size, typ) => "makeblock :size " + size + " :type: " + blockT.apply(typ).toString() + "\n"
	  case makefloatblock(size) => "makefloatblock :size " + size + "\n"
	    
	  case const(arg) => "const" + arg + "\n"
	  case pushconst(arg) => "pushconst" + arg + "\n"
	  case pushconstint(arg) => "pushconstint (" + arg + ")\n"
	  case constint(arg) => "constint (" + arg + ")\n"
	    
	  case _ => "Instruction inconnue"
	}
}

/**
 * Les instructions possibles de la ZAM
 */

case class acc(arg : Int) extends Instruction
case class push extends Instruction
case class pushacc(arg : Int) extends Instruction
case class pop(arg : Int) extends Instruction
case class assign(arg : Int) extends Instruction

case class envacc(arg : Int) extends Instruction
case class pushenvacc(arg : Int) extends Instruction

case class pushgetglobal(arg : Int) extends Instruction
case class getglobal(arg : Int) extends Instruction
case class getglobalfield(arg : Int, field : Int) extends Instruction
case class setglobal(arg : Int) extends Instruction
case class pushgetglobalfield(arg: Int, field : Int) extends Instruction

case class getfield(arg : Int) extends Instruction
case class getfloatfield(arg : Int) extends Instruction
case class setfield(arg : Int) extends Instruction
case class setfloatfield(arg : Int) extends Instruction
case class pushatom(arg : Int) extends Instruction
case class atom(arg : Int) extends Instruction
case class makeblock(size : Int, typ : Int) extends Instruction
case class makefloatblock(size : Int) extends Instruction

case class const(arg : Int) extends Instruction
case class pushconst(arg : Int) extends Instruction
case class pushconstint(arg : Int) extends Instruction
case class constint(arg : Int) extends Instruction