package ZAM

/**
 * Implantation des instructions (interpret)
 * arg permet de factoriser les ACC(n) et autres instructions de ce type
 * Pour les instructions ayant besoin de valeur, elles sont passées en argument
 */
class Instruction (t : instrT.instrT, arg : Int = 0, champ : Int = 0) {
  
  /**
   * Execute l'instruction (t) pour la thread itT
   * Cela comprend la sauvegarde et la mise à jour des valeurs de la thread
   */
  def exec(itT : Int) = {
    //sauvegarde de l'etat
    EtatGlobal.getthread(itT).sauverEtat
    var accu = EtatGlobal.getaccu(itT)
    var sp = EtatGlobal.getsp(itT)
    var pc = EtatGlobal.getpc(itT)
    
    t match {
    
    case instrT.acc => EtatGlobal.setaccu(itT, sp.get(arg));
    case instrT.push => sp.add(accu)
    case instrT.pushacc => sp.add(accu); if (arg > 0) EtatGlobal.setaccu(itT, sp.get(arg))
    case instrT.pop => for(i<-0 to arg) sp.remove(sp.size-1)
    case instrT.assign => sp.set(arg,accu)
    
    case instrT.pushgetglobal => sp.add(accu); EtatGlobal.setaccu(itT, EtatGlobal.getglob.get(arg))
	case instrT.getglobal => EtatGlobal.setaccu(itT, EtatGlobal.getglob.get(arg))
	case instrT.pushgetglobalfield => sp.add(accu); accu = EtatGlobal.getglob.get(arg)
									EtatGlobal.setaccu(itT, accu.asInstanceOf[Zamblock].at(champ))
									
	case instrT.getglobalfield => accu = EtatGlobal.getglob.get(arg); EtatGlobal.setaccu(itT, accu.asInstanceOf[Zamblock].at(champ))
	case instrT.setglobal => EtatGlobal.addglob(arg, accu); EtatGlobal.setaccu(itT, new Zamentier(0))
	
	case instrT.envacc => EtatGlobal.setaccu(itT, EtatGlobal.getenv(itT, arg))
	case instrT.pushenvacc => sp.add(accu); EtatGlobal.setaccu(itT, EtatGlobal.getglob.get(arg))
    
	
    case instrT.const => EtatGlobal.setaccu(itT, new Zamentier(arg))
	case instrT.pushconst => sp.add(accu);EtatGlobal.setaccu(itT, new Zamentier(arg))
	case instrT.pushconstint => sp.add(accu)
	case instrT.constint => EtatGlobal.setaccu(itT, new Zamentier(arg))
	    
    case _=> ()
    }
    pc = pc +1
    //mise à jour du pc
    EtatGlobal.getthread(itT).setpc(pc)
  }
  
	override def toString = t match {
	  case instrT.acc => var str = "acc "
	    				if(arg!=0) str += arg
	    				str +="\n"
	    				str
	  case instrT.push => "push\n"
	  case instrT.pushacc => var str = "pushacc "
	    				if(arg!=0) str += arg
	    				str +="\n"
	    				str
	  case instrT.pop => var str = "pop "
	    				if(arg!=0) str += arg
	    				str +="\n"
	    				str
	  case instrT.assign => "assign\n"
	    
	  case instrT.pushgetglobal => "pushgetglobal "
	  case instrT.getglobal => "getglobal"
	  case instrT.getglobalfield => "getglobalfield"
	  case instrT.setglobal => "setglobal"
	  case instrT.envacc => "envacc"
	  case instrT.pushenvacc => "pushenvacc"
	  case instrT.pushgetglobalfield => "pushgetglobalfield"
	    
	  case instrT.getfield => "getfield"
	  case instrT.getfloatfield => "getfloatfield"
	  case instrT.setfield => "setfield"
	  case instrT.setfloatfield => "setfloatfield"
	  case instrT.pushatom => "pushatom"
	  case instrT.atom => "atom"
	  case instrT.pushatom => "pushatom"
	  case instrT.makefloatblock => "makefloatblock"
	    
	  case instrT.const => "const" + arg + "\n"
	  case instrT.pushconst => "pushconst" + arg + "\n"
	  case instrT.pushconstint => "pushconstint\n"
	  case instrT.constint => "constint\n"
	    
	  case _ => "Instruction inconnue"
	}
}