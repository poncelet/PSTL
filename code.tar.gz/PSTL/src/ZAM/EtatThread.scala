package ZAM
import java.util.ArrayList
import java.util.HashMap
/**
 * Etat dynamique d'une thread
 * Elle comporte ses valeurs locales et son pc.
 * Son chemin sauvegarde le parcours effectué
 */
class EtatThread {
	var sp = new ArrayList[Value]()
	var accu : Value = new Zamentier(0) //unit
	var env = new ArrayList[Value](4)
	var pc = 0
	val chemin = new ArrayList[state]()
	
	/**
	 * Acces à l'environnement
	 */
	def getenv(i : Int) = env.get(i)
	def setenv(i : Int, v : Value) = env.set(i, v)
	
	/**
	 * Acces au pointeur d'instruction
	 */
	def getpc = pc
	def setpc(newpc : Int) = pc = newpc
	
	/**
	 * Acces au chemin
	 */
	def getchemin = chemin
	def addchemin(newstate : state) = chemin.add(newstate)
	
	/**
	 * Acces à sa pile
	 */
	def getsp = sp
	def addsp(v : Value) = sp.add(v)
  
	/**
	 * Acces à son accumulateur
	 */
	def getaccu = accu
	def setaccu(v : Value) = accu = v
	
	/**
	 * Ajoute dans son chemin l'état courant de la thread et de l'état global
	 */
	def sauverEtat = {	// Copy de pile
						var stk = new ArrayList[Value](sp.size())
						for(i<-0 to sp.size-1) stk.add(sp.get(i))
						//Copy de tas
						var globtmp = new HashMap[Int, Value](EtatGlobal.getglob)
						var envtmp = new ArrayList[Value](env)
						addchemin(new state(pc, stk, accu, envtmp ,globtmp, EtatGlobal.getextra))}
	/**
	 * Restaure le n° chemin (et met aussi à jour le chemin)
	 */
	def restaurer(n : Int) = { val stateit = getchemin.get(n)
						// Restaurer Pile
						sp.clear()
						for(i<-0 to stateit.getsp.size-1) sp.add(stateit.getsp.get(i))
						// Environnement
						env.clear()
						for(i<-0 to 4) setenv(i, stateit.getenv.get(i)) 
						// Restaurer tas
						EtatGlobal.getglob.clear()
						EtatGlobal.setglob(new HashMap[Int, Value](stateit.getglob))
						pc = stateit.getpc
						accu = stateit.getaccu
						EtatGlobal.setextra(stateit.getextra)
						// Restaurer le chemin
						for(i<-0 to n) chemin.remove(chemin.size()-1)
	}
	
	override def toString() = " sp : " + sp.toString + " : accu " + accu + " pc " + pc

}