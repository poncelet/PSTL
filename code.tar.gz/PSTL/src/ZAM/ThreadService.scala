package ZAM

/**
 * Lien entre ZAM et IHM (à faire implanter par simulateur et requérir à fenêtre)
 */
trait ThreadService {

}