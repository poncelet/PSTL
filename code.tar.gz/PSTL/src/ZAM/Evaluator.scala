package ZAM
import scala.collection.mutable.ArrayBuffer

/**
 * Classe Evaluator
 * Elle est chargée d'évaluer une instruction sur un environnement
 **/
class Evaluator {

  val MAX_YOUNG_WOSIZE = 256
  val DOUBLE_WOSIZE = 1 //double size / value size
  
  /**
 * Avance la thread t d'un pas en appliquant l'instruction qu'elle pointe
 * inst : L'instruction evaluée
 * Env : L'environnement courant
 * t :Int Le numéro de la thread qui s'exécute
 */
 def exec(inst : Instruction, env : GlobalState, itT : Int) = {
   
    //sauvegarde de l'etat
    var thread = env.getthread(itT)
    
    inst match {
    
    case Acc(arg) => thread.setaccu(thread.getsp(arg))
    case Push() => thread.addsp(thread.getaccu)
    case Pushacc(arg) => thread.addsp(thread.getaccu); if (arg > 0) thread.setaccu(thread.getsp(arg))
    case Pop(arg) => for(i<-0 to arg) thread.getsp.remove(thread.getsp.size-1)
    case Assign(arg) => thread.getsp.update(arg,thread.getaccu)
    
    case Envacc(arg) => thread.setaccu(thread.getenv(arg))
	case Pushenvacc(arg) => thread.addsp(thread.getaccu); thread.setaccu(thread.getenv(arg))
	
	case Push_Retaddr(pc) => {	thread.addsp(new Zamentier(thread.getpc + pc))
								thread.addsp(new Zamblock(BlockT.double_t, 4, Array[Value](thread.getenv(0), thread.getenv(1), thread.getenv(2), thread.getenv(3))))
								thread.addsp(new Zamlong(thread.getextra))}
	case Apply(arg) => {	if( (arg > 0) && (arg < 4)) {
								for(i<-1 to arg) {
									thread.addsp(thread.getsp(i))
								}
								thread.addsp(new Zamentier(thread.getpc))
								thread.addsp(new Zamblock(BlockT.double_t, 4, Array[Value](thread.getenv(0), thread.getenv(1), thread.getenv(2), thread.getenv(3))))
								thread.addsp(new Zamlong(thread.getextra))
							}
							else {
								thread.setextra(arg - 1)
								thread.setpc(thread.getaccu.asInstanceOf[Zamentier].getval)
								for(i<-0 to 3) thread.setenv(i, thread.getaccu.asInstanceOf[Zamblock].at(i))
							}
						}//check_stack
	case Appterm(nargs, slotSize) => {	}
	case Return(sp) => "return " + sp + "\n" 
	case Restart() => "restart \n"
	case Grab(required) => "grab " + required + "\n"
	case Closure(nvars) => "closure " + nvars + "\n"
	case Closurerec(nfuncs, nvars) => "closurerec " + nfuncs + ", " + nvars + "\n"
	case Pushoffsetclosure(arg) => "pushoffsetclosure " + arg + "\n"
	case Offsetclosure(arg) => "offsetclosure " + arg + "\n"
	case Pushoffsetclosurem(arg) => "pushoffsetclosurem " + arg + "\n"
	case Offsetclosurem(arg) => "offsetclosurem " + arg + "\n"
	
    case Pushgetglobal(arg) => thread.addsp(thread.getaccu); thread.setaccu(env.atglob(arg))
	case Getglobal(arg) => thread.setaccu(env.atglob(arg))
	case Getglobalfield(arg, field) => thread.addsp(thread.getaccu); thread.setaccu(env.atglob(arg))
									thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(field))
	case Setglobal(arg) => env.addglob(arg, thread.getaccu); thread.setaccu(new Zamentier(0))
	case Pushgetglobalfield(arg, field) => thread.setaccu(env.atglob(arg)); thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(field))
	
	
	case Getfield(arg) => thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(arg))
	case Getfloatfield(arg) => thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(arg)) //double_t clone ?
	case Setfield(arg) => thread.getaccu.asInstanceOf[Zamblock].set(arg, thread.getsp(thread.getsp.size-1))
	case Setfloatfield(arg) => thread.getaccu.asInstanceOf[Zamblock].set(arg, thread.getsp(thread.getsp.size-1)); thread.setaccu(new Zamentier(0)) //double_t
	case Pushatom(arg) => thread.addsp(thread.getaccu); thread.setaccu(new Zamentier(arg))//accu = atom(arg) autre Hash ? gc.h/mlvalues/ alloc.c > traitement des headers
	case Atom(arg) => thread.setaccu(new Zamentier(arg))//accu = Tag ? // Transform. int > Value = blockT.getValue(arg)
	case Makeblock(size, typ) => { 
	  //size = arg, tag = champ
	  //alloc_small(cilbe, size, tag)
	  var block : Zamblock = null
	  if(size <= MAX_YOUNG_WOSIZE) {
		  block = new Zamblock(BlockT.apply(typ), size, new Array[Value](size))
		  block.set(0, thread.getaccu)
		  for(i<-1 to size-1) {block.set(i, thread.getsp(thread.getsp.size-1));thread.getsp.remove(thread.getsp.size-1)}
	  }
	  else {
	      block = new Zamblock(BlockT.apply(typ), size, new Array[Value](size))
		  block.set(0, thread.getaccu)
		  for(i<-1 to size-1) {block.set(i, thread.getsp(thread.getsp.size-1));thread.getsp.remove(thread.getsp.size-1)}
	  }
	  thread.setaccu(block)
	}
	case Makefloatblock(size) => {
	  // size = arg
	  var block : Zamblock = null
	  if( size <= MAX_YOUNG_WOSIZE / DOUBLE_WOSIZE) {
	    block = new Zamblock(BlockT.doublearray_t, size * DOUBLE_WOSIZE, new Array[Value](size))
	  }
	  else {
	     block = new Zamblock(BlockT.doublearray_t, size * DOUBLE_WOSIZE, new Array[Value](size))
	  }
	  block.set(0, thread.getaccu) //Double_t 
	  for(i <- 1 to size-1) {block.set(i, thread.getsp(thread.getsp.size-1));thread.getsp.remove(thread.getsp.size-1)} //Double_t
	  thread.setaccu(block)
	}
	
	case Vectlength() => {var mlsize = thread.getaccu.asInstanceOf[Zamblock].getsize
	  						if(thread.getaccu.asInstanceOf[Zamblock].gettag == BlockT.doublearray_t) mlsize = mlsize / DOUBLE_WOSIZE
	  						thread.setaccu(new Zamlong(mlsize))}
	case Getvectitem() => {thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].getval(
							thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
							thread.getsp.remove(thread.getsp.size-1)}
	case Setvectitem() => {thread.getaccu.asInstanceOf[Zamblock].set(
							thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval,
							thread.getsp(thread.getsp.size-2))
							thread.getsp.remove(thread.getsp.size-1);thread.getsp.remove(thread.getsp.size-1)}
	
	case Branch(flag) => thread.setpc(thread.getpc + (flag-1))
	case Branchif(flag) => {if(thread.getaccu.asInstanceOf[Zamentier].getval != 0) thread.setpc(thread.getpc + (flag-1))}
	case Branchifnot(flag) => {if(thread.getaccu.asInstanceOf[Zamentier].getval == 0) thread.setpc(thread.getpc + (flag-1))}
	case Switch(sizes,flags) => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamblock")) {
									val index = thread.getaccu.asInstanceOf[Zamblock].gettag.id
									thread.setpc(thread.getpc + (flags((sizes & 0xFFFF) + index)) -1)
								}
								else {
								  val index = thread.getaccu.asInstanceOf[Zamentier].getval
								  thread.setpc(thread.getpc + (flags(index)-1))
								}}
	case Boolnot() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							if(thread.getaccu.asInstanceOf[Zamentier].getval == 0) thread.setaccu(new Zamentier(1))
							else thread.setaccu(new Zamentier(1))
						}
						else {
							if(thread.getaccu.asInstanceOf[Zamlong].getval == 0) thread.setaccu(new Zamentier(1))
							else thread.setaccu(new Zamentier(1))
						}} //?
	
	case C_Call(narg) => { //arg Block(custom ?)
	  //sauv
	val pc = thread.getpc
	val env = new Array[Value](4)
	for(i<-0 to 3) env(i) = thread.getenv(i)
	val sp = thread.getsp
	
	//lancement primitive
	//thread.setaccu()
	
	//restaure
	thread.setpc(pc+1)
	for(i<-0 to 3) thread.setenv(i, env(i))
	thread.sp = sp //?
	}
    
    case Const(arg) => thread.setaccu(new Zamentier(arg))
	case Pushconst(arg) => thread.addsp(thread.getaccu); thread.setaccu(new Zamentier(arg))
	case Pushconstint(arg) => thread.addsp(thread.getaccu); thread.setaccu(new Zamentier(arg))
	case Constint(arg) => thread.setaccu(new Zamentier(arg))
	
	case Negint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier(~thread.getaccu.asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(~thread.getaccu.asInstanceOf[Zamlong].getval))
						}} //?
	case Addint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						+	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval)) //-1 ?
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						+	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Subint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						-	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval)) //+1 ?
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						-	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Mulint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						*	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						*	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Divint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) { //test div == 0? (sp[0] != 0)
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						/	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						/	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Modint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) { //test div == 0? (sp[0] != 0)
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						%	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						%	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}

	case Andint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						&	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						&	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Orint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval
							    						|	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						|	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Xorint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier( thread.getaccu.asInstanceOf[Zamentier].getval
							    						^	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong( thread.getaccu.asInstanceOf[Zamlong].getval
							    						^	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval ))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Lslint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier( thread.getaccu.asInstanceOf[Zamentier].getval
							    						<< thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						<< 	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Lsrint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier( thread.getaccu.asInstanceOf[Zamentier].getval
							    						>> thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						>> 	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}
	case Asrint() => {if(thread.getaccu.getClass().toString().equals("class ZAM.Zamentier")) {
							thread.setaccu(new Zamentier( thread.getaccu.asInstanceOf[Zamentier].getval
							    						>> thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval))
						}
						else {
							thread.setaccu(new Zamlong(thread.getaccu.asInstanceOf[Zamlong].getval
							    						>> 	thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval))
						}
						thread.getsp.remove(thread.getsp.size-1)}

	case Integer_comparision(tst) => { 
	  var val1 : Long = 0
	  var val2 : Long = 0
	  var res = false
	  val Strclass = thread.getaccu.getClass().toString()
	  if(! Strclass.equals(thread.getsp(thread.getsp.size-1).getClass().toString()))
	    thread.setaccu(new Zamentier(0))
	  else {
	    Strclass match {
	      case "class ZAM.Zamentier" => val1 = thread.getaccu.asInstanceOf[Zamentier].getval; val2 = thread.getsp(thread.getsp.size-1).asInstanceOf[Zamentier].getval
	      case "class ZAM.Zamlong" => val1 = thread.getaccu.asInstanceOf[Zamlong].getval; val2 = thread.getsp(thread.getsp.size-1).asInstanceOf[Zamlong].getval
	    }
		  tst match {
		  case "EQ" => res = val1 == val2
		  case "NEQ" => res = val1 != val2
		  case "LTINT" => res = val1 < val2
		  case "LEINT" => res = val1 <= val2
		  case "GTINT" => res = val1 > val2
		  case "GEINT" => res = val1 >= val2
		  case "ULTINT" => res = val1 < val2 // U ?
		  case "UGEINT" => res = val1 >= val2
		  }
		  if(res) thread.setaccu(new Zamentier(1))
		  else thread.setaccu(new Zamentier(0))
	  	  }
	  	thread.getsp.remove(thread.getsp.size-1)}

	case Integer_branch_comparision(arg : Long, pc : Int, tst: String) => {
	   var val1 : Long = 0
	   var res = false
	   thread.getaccu.getClass().toString() match {
	   	  case "class ZAM.Zamentier" => val1 = thread.getaccu.asInstanceOf[Zamentier].getval
	      case "class ZAM.Zamlong" => val1 = thread.getaccu.asInstanceOf[Zamlong].getval
	    }
		  tst match {
		  case "BEQ" => res = arg == val1
		  case "BNEQ" => res = arg != val1
		  case "BLTINT" => res = arg < val1
		  case "BLEINT" => res = arg <= val1
		  case "BGTINT" => res = arg > val1
		  case "BGEINT" => res = arg >= val1
		  case "BULTINT" => res = arg < val1
		  case "BUGEINT" => res = arg >= val1
		  }
		  if(res) thread.setpc(thread.getpc + (pc-1))}

	case Offsetint(arg) => thread.setaccu(new Zamentier(thread.getaccu.asInstanceOf[Zamentier].getval + (arg << 1)))
	case Offsetref(arg) => "offsetref " + arg + "\n"//pointeur ?
	case Isint() => val res = thread.getaccu.getClass().toString.equals("class ZAM.Zamentier"); thread.setaccu(new Zamentier(res.asInstanceOf[Int]))
	    
    case _=> ()
    }
    //mise à jour du pc
    thread.setpc(thread.getpc + 1)
  }

}