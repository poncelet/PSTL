package ZAM

/**
 * Classe Evaluator
 * Elle est chargée d'évaluer une instruction sur un environnement
 **/
class Evaluator {

  val MAX_YOUNG_WOSIZE = 256
  val DOUBLE_WOSIZE = 1 //double size / value size
  
  /**
 * Avance la thread t d'un pas en appliquant l'instruction qu'elle pointe
 * inst : L'instruction evaluée
 * Env : L'environnement courant
 * t :Int Le numéro de la thread qui s'exécute
 */
 def exec(inst : Instruction, env : GlobalState, itT : Int) = {
   
    //sauvegarde de l'etat
    var thread = env.getthread(itT)
    
    inst match {
    
    case Acc(arg) => thread.setaccu(thread.getsp(arg))
    case Push() => thread.addsp(thread.getaccu)
    case Pushacc(arg) => thread.addsp(thread.getaccu); if (arg > 0) thread.setaccu(thread.getsp(arg))
    case Pop(arg) => for(i<-0 to arg) thread.getsp.remove(thread.getsp.size-1)
    case Assign(arg) => thread.getsp.update(arg,thread.getaccu)
    
    case Envacc(arg) => thread.setaccu(thread.getenv(arg))
	case Pushenvacc(arg) => thread.addsp(thread.getaccu); thread.setaccu(thread.getenv(arg))
	
	case Push_Retaddr(pc) => {	thread.addsp(new Zamentier(thread.getpc + pc))
								thread.addsp(new Zamblock(BlockT.double_t, 4, Array[Value](thread.getenv(0), thread.getenv(1), thread.getenv(2), thread.getenv(3))))
								thread.addsp(new Zamlong(thread.getextra))}
	case Apply(arg) => {	if( (arg > 0) && (arg < 4)) {
								for(i<-1 to arg) {
									thread.addsp(thread.getsp(i))
								}
								thread.addsp(new Zamentier(thread.getpc))
								thread.addsp(new Zamblock(BlockT.double_t, 4, Array[Value](thread.getenv(0), thread.getenv(1), thread.getenv(2), thread.getenv(3))))
								thread.addsp(new Zamlong(thread.getextra))
							}
							else {
								thread.setextra(arg - 1)
								thread.setpc(thread.getaccu.asInstanceOf[Zamentier].getval)
								for(i<-0 to 3) thread.setenv(i, thread.getaccu.asInstanceOf[Zamblock].at(i))
							}
						}//check_stack
	case Appterm(nargs, slotSize) => {	value = new Zamentier()}
	case Return(sp) => "return " + sp + "\n" 
	case Restart() => "restart \n"
	case Grab(required) => "grab " + required + "\n"
	case Closure(nvars) => "closure " + nvars + "\n"
	case Closurerec(nfuncs, nvars) => "closurerec " + nfuncs + ", " + nvars + "\n"
	case Pushoffsetclosure(arg) => "pushoffsetclosure " + arg + "\n"
	case Offsetclosure(arg) => "offsetclosure " + arg + "\n"
	case Pushoffsetclosurem(arg) => "pushoffsetclosurem " + arg + "\n"
	case Offsetclosurem(arg) => "offsetclosurem " + arg + "\n"
	
    case Pushgetglobal(arg) => thread.addsp(thread.getaccu); thread.setaccu(env.atglob(arg))
	case Getglobal(arg) => thread.setaccu(env.atglob(arg))
	case Getglobalfield(arg, field) => thread.addsp(thread.getaccu); thread.setaccu(env.atglob(arg))
									thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(field))
	case Setglobal(arg) => env.addglob(arg, thread.getaccu); thread.setaccu(new Zamentier(0))
	case Pushgetglobalfield(arg, field) => thread.setaccu(env.atglob(arg)); thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(field))
	
	
	case Getfield(arg) => thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(arg))
	case Getfloatfield(arg) => thread.setaccu(thread.getaccu.asInstanceOf[Zamblock].at(arg)) //double_t clone ?
	case Setfield(arg) => thread.getaccu.asInstanceOf[Zamblock].set(arg, thread.getsp(thread.getsp.size-1))
	case Setfloatfield(arg) => thread.getaccu.asInstanceOf[Zamblock].set(arg, thread.getsp(thread.getsp.size-1)); thread.setaccu(new Zamentier(0)) //double_t
	case Pushatom(arg) => thread.addsp(thread.getaccu); thread.setaccu(new Zamentier(arg))//accu = atom(arg) autre Hash ? gc.h/mlvalues/ alloc.c > traitement des headers
	case Atom(arg) => thread.setaccu(new Zamentier(arg))//accu = Tag ? // Transform. int > Value = blockT.getValue(arg)
	case Makeblock(size, typ) => { 
	  //size = arg, tag = champ
	  //alloc_small(cilbe, size, tag)
	  var block : Zamblock = null
	  if(size <= MAX_YOUNG_WOSIZE) {
		  block = new Zamblock(BlockT.apply(typ), size, new Array[Value](size))
		  block.set(0, thread.getaccu)
		  for(i<-1 to size-1) block.set(i, thread.getsp(i-1))
	  }
	  else {
	      block = new Zamblock(BlockT.apply(typ), size, new Array[Value](size))
		  block.set(0, thread.getaccu)
		  for(i<-1 to size-1) block.set(i, thread.getsp(i-1))
	  }
	  thread.setaccu(block)
	}
	case Makefloatblock(size) => {
	  // size = arg
	  var block : Zamblock = null
	  if( size <= MAX_YOUNG_WOSIZE / DOUBLE_WOSIZE) {
	    block = new Zamblock(BlockT.doublearray_t, size * DOUBLE_WOSIZE, new Array[Value](size))
	  }
	  else {
	     block = new Zamblock(BlockT.doublearray_t, size * DOUBLE_WOSIZE, new Array[Value](size))
	  }
	  block.set(0, thread.getaccu) //Double_t 
	  for(i <- 1 to size-1) block.set(i, thread.getsp(i-1)) //Double_t
	  thread.setaccu(block)
	}
    
    case Const(arg) => thread.setaccu(new Zamentier(arg))
	case Pushconst(arg) => thread.addsp(thread.getaccu); thread.setaccu(new Zamentier(arg))
	case Pushconstint(arg) => thread.addsp(thread.getaccu); thread.setaccu(new Zamentier(arg))
	case Constint(arg) => thread.setaccu(new Zamentier(arg))
	    
    case _=> ()
    }
    //mise à jour du pc
    thread.setpc(thread.getpc + 1)
  }

}