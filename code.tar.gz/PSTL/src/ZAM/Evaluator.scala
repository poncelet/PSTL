package ZAM

class Evaluator {

  /**
 * Avance la thread t d'un pas en appliquant l'instruction qu'elle pointe
 */
def avancer(t : Int) = arbre.get(EtatGlobal.getpc(t)).exec(t)

/**
   * Execute l'instruction (t) pour la thread itT
   * Cela comprend la sauvegarde et la mise à jour des valeurs de la thread
   */
  def exec(itT : Int) = {
    //sauvegarde de l'etat
    EtatGlobal.getthread(itT).sauverEtat
    var accu = EtatGlobal.getaccu(itT)
    var sp = EtatGlobal.getsp(itT)
    var pc = EtatGlobal.getpc(itT)
    
    t match {
    
    case instrT.acc => EtatGlobal.setaccu(itT, sp.get(arg));
    case instrT.push => sp.add(accu)
    case instrT.pushacc => sp.add(accu); if (arg > 0) EtatGlobal.setaccu(itT, sp.get(arg))
    case instrT.pop => for(i<-0 to arg) sp.remove(sp.size-1)
    case instrT.assign => sp.set(arg,accu)
    
    case instrT.pushgetglobal => sp.add(accu); EtatGlobal.setaccu(itT, EtatGlobal.getglob.get(arg))
	case instrT.getglobal => EtatGlobal.setaccu(itT, EtatGlobal.getglob.get(arg))
	case instrT.pushgetglobalfield => sp.add(accu); accu = EtatGlobal.getglob.get(arg)
									EtatGlobal.setaccu(itT, accu.asInstanceOf[Zamblock].at(champ))
									
	case instrT.getglobalfield => accu = EtatGlobal.getglob.get(arg); EtatGlobal.setaccu(itT, accu.asInstanceOf[Zamblock].at(champ))
	case instrT.setglobal => EtatGlobal.addglob(arg, accu); EtatGlobal.setaccu(itT, new Zamentier(0))
	
	case instrT.envacc => EtatGlobal.setaccu(itT, EtatGlobal.getenv(itT, arg))
	case instrT.pushenvacc => sp.add(accu); EtatGlobal.setaccu(itT, EtatGlobal.getglob.get(arg))
	
	case instrT.getfield => EtatGlobal.setaccu(itT, accu.asInstanceOf[Zamblock].at(arg))
	case instrT.getfloatfield => EtatGlobal.setaccu(itT, accu.asInstanceOf[Zamblock].at(arg)) //double_t clone ?
	case instrT.setfield => accu.asInstanceOf[Zamblock].set(arg, sp.get(0)) //sp++ ?
	case instrT.setfloatfield => accu.asInstanceOf[Zamblock].set(arg, sp.get(0)); EtatGlobal.setaccu(itT, new Zamentier(0)) //double_t
	case instrT.pushatom => sp.add(accu);EtatGlobal.setaccu(itT, new Zamentier(arg))//accu = atom(arg) autre Hash ? gc.h/mlvalues/ alloc.c > traitement des headers
	case instrT.atom => EtatGlobal.setaccu(itT, new Zamentier(arg))//accu = Tag ? // Transform. int > Value = blockT.getValue(arg)
	case instrT.makeblock => { 
	  //size = arg, tag = champ
	  //alloc_small(cilbe, size, tag)
	  var block : Zamblock = null
	  if(arg <= MAX_YOUNG_WOSIZE) {
		  block = new Zamblock(blockT.apply(champ), arg, new ArrayList[Value](arg))
		  block.set(0, accu)
		  for(i<-1 to arg) block.set(i, sp.get(i))
	  }
	  else {
	     block = new Zamblock(blockT.apply(champ), arg, new ArrayList[Value](arg))
	     block.set(0, accu)
	     for(i<-1 to arg) block.set(i, sp.get(i))
	  }
	  EtatGlobal.setaccu(itT, block)
	}
	
	case instrT.makefloatblock => {
	  // size = arg
	  var block : Zamblock = null
	  if( arg <= MAX_YOUNG_WOSIZE / DOUBLE_WOSIZE) {
	    block = new Zamblock(blockT.doublearray_t, arg * DOUBLE_WOSIZE, new ArrayList[Value](arg))
	  }
	  else {
	     block = new Zamblock(blockT.doublearray_t, arg * DOUBLE_WOSIZE, new ArrayList[Value](arg))
	  }
	  block.set(0, accu) //Double_t 
	  for(i <- 1 to arg) block.set(i, sp.get(i)) //Double_t
	  EtatGlobal.setaccu(itT, block)
	}
    
    case instrT.const => EtatGlobal.setaccu(itT, new Zamentier(arg))
	case instrT.pushconst => sp.add(accu);EtatGlobal.setaccu(itT, new Zamentier(arg))
	case instrT.pushconstint => sp.add(accu)
	case instrT.constint => EtatGlobal.setaccu(itT, new Zamentier(arg))
	    
    case _=> ()
    }
    pc = pc +1
    //mise à jour du pc
    EtatGlobal.getthread(itT).setpc(pc)
  }

}