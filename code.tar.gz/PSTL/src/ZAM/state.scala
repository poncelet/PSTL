package ZAM
import java.util.HashMap
import java.util.ArrayList

/**
 * Un etat du programme
 * Il comporte le pointeur de code, la pile, l'accumulateur, l'environnement, les variables globales et l'extra arg
 */
class state (pc : Int, sp : ArrayList[Value], accu : Value, env : ArrayList[Value], glob : HashMap[Int, Value], extra_args : Int){

  def getpc = pc
  def getsp = sp
  def getaccu = accu
  def getenv = env
  def getglob = glob
  def getextra = extra_args

}