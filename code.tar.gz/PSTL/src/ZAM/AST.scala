package ZAM
import java.util.ArrayList
/**
 * Classe AST
 * Elle détient la suite d'instruction pointée par les pcs
 */
class AST {
val arbre = new ArrayList[Instruction]()

override def toString = { var str = "AST : \n"
						for(i<-0 to arbre.size-1) str += arbre.get(i).toString
						str
						}
/**
 * Ajouter une instruction (de type instruction, les valeurs associées sont données en arguments)
 */
def add(instr : Instruction) = arbre.add(instr)
/**
 * Retourne l'instruction pointée par ce pc
 */
def get(pc : Int) : Instruction = arbre.get(pc)

/**
 * Avance la thread t d'un pas en appliquant l'instruction qu'elle pointe
 */
def avancer(t : Int) = arbre.get(EtatGlobal.getpc(t)).exec(t)
}