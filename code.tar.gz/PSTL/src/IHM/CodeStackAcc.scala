package IHM

class CodeStackAcc(Thr : ZAM.ThreadService) {

}