package IHM
import javax.swing.JPanel

trait Vue extends JPanel {
/* using textComponent */
}