package IHM
import javax.swing.JPanel
import java.awt.event.ActionListener
import java.awt.event.ActionEvent

object MyFileChooser extends JPanel with ActionListener {

  def actionPerformed(e : ActionEvent) {}
}